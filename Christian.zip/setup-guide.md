# Connecting "The Well" to its real backend (Supabase)

This turns the onboarding form, the Room, and the admin console from a demo into
something real: an actual database, actual accounts, and actual emails sent to people
when they sign up or log in. It takes about 10 minutes and costs nothing to start.

## 1. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) and sign up (free).
2. Click **New project**. Give it a name like "the-well", set a database password
   (save it somewhere safe — you likely won't need it day-to-day), and pick a region
   close to your members.
3. Wait about a minute for the project to finish setting up.

## 2. Create the members table

1. In your Supabase project, open **SQL Editor** in the left sidebar.
2. Click **New query**.
3. Open the `schema.sql` file (included alongside this guide), copy all of it, and
   paste it into the editor.
4. Click **Run**. You should see "Success. No rows returned."

This creates the `members` table and locks it down with Row Level Security, so:
- Each person can only ever see their own profile.
- Only `onimisibello3@gmail.com` can see everyone's profile (this is what makes the
  admin console work) or remove a member.

## 3. Make sign-in emails show a code, not a link

By default, Supabase's magic-link emails contain a clickable link. The site is built
to use a **typed-in 6-digit code** instead, so you need to change the email template:

1. Go to **Authentication → Email Templates** in the sidebar.
2. Select the **Magic Link** template.
3. Replace the body so it shows `{{ .Token }}` instead of the confirmation link, e.g.:

   ```
   <h2>Your code for The Well</h2>
   <p>Enter this code to continue: <strong>{{ .Token }}</strong></p>
   <p>This code expires shortly, so use it soon.</p>
   ```
4. Save.

Supabase's free tier includes a limited number of emails per hour sent from their own
address — fine for testing and a small community. If you outgrow it, Supabase lets you
plug in your own SMTP (e.g. Gmail, Resend, Postmark) under **Project Settings → Auth →
SMTP Settings**, so the emails come from your own domain instead.

## 4. Connect the website to your project

1. In Supabase, go to **Project Settings → API**.
2. Copy the **Project URL** and the **anon public** key (not the `service_role` key —
   that one must never be placed in a public webpage).
3. Open `the-well.html` and find this block near the top of the first `<script>` tag:

   ```javascript
   const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
   const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
   ```
4. Replace both placeholder values with what you copied.

## 5. Try it

1. Open `the-well.html` in a normal browser tab (not inside a chat window).
2. Click **Join the Well** and fill out the form.
3. On the last step, click **Send my code** — check the inbox of the email you used.
4. Enter the code you received. You should land on the welcome screen, and the Room
   should be open to you.
5. Check **Authentication → Users** and **Table Editor → members** in Supabase — you
   should see your new sign-up in both places.
6. To test the admin console: click **Admin console** in the footer, and go through
   the same email-code flow using `onimisibello3@gmail.com`. You should see every
   member listed, with stats and a CSV export.

## What this gives you vs. what it still doesn't

**Now real:**
- Actual accounts, backed by a real database
- Actual one-time codes emailed to people (no more on-screen fake codes)
- Row-level security — the admin console genuinely cannot be read by anyone except
  the owner account, enforced by the database itself, not just by front-end code

**Still worth knowing:**
- The **prayer wall** is still session-only (resets on refresh) — it was never asked
  to persist, but say the word if you want it saved to the database too.
- Supabase's free-tier default email sending is meant for low volume / testing. For a
  real community, plan to connect your own SMTP or a transactional email service
  eventually — this is a config change in Supabase, not a rebuild of the site.
- Anyone can still view the site's HTML/JS source (that's just how websites work) —
  but because the anon key only grants what your Row Level Security rules allow, that
  key being visible isn't a security hole the way a real secret key would be.
