-- The Well — Supabase schema
-- Run this once in your Supabase project: Project > SQL Editor > New query > paste > Run

-- 1. Members table. Each row is linked 1:1 to a Supabase Auth user (created automatically
--    the first time someone verifies an email code, via signInWithOtp + verifyOtp).
create table if not exists members (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null,
  phone text,
  city text,
  age text,
  journey text,
  interests text[] default '{}',
  joined_at timestamptz not null default now()
);

-- 2. Turn on Row Level Security — without this, anyone with your anon key could read
--    or write any row. With it, the rules below are the ONLY way in.
alter table members enable row level security;

-- 3. A member can see their own profile.
create policy "members can view own profile"
  on members for select
  using (auth.uid() = id);

-- 4. The owner (Bello) can see every profile — this is what powers the admin console.
create policy "owner can view all profiles"
  on members for select
  using (auth.jwt() ->> 'email' = 'onimisibello3@gmail.com');

-- 5. A signed-in user can create their own profile row (used right after onboarding).
create policy "members can insert own profile"
  on members for insert
  with check (auth.uid() = id);

-- 6. A signed-in user can update their own profile later if needed.
create policy "members can update own profile"
  on members for update
  using (auth.uid() = id);

-- 7. Only the owner can delete a member (used by the "Remove" button in the admin console).
create policy "owner can delete any profile"
  on members for delete
  using (auth.jwt() ->> 'email' = 'onimisibello3@gmail.com');
